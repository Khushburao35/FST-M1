package Activity;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class Activity01 {
	
	WebDriver driver;
	
	@Test
	public void test1() 
	{
		String title = driver.getTitle();
		System.out.println(title);
		assertEquals(title,"Training Support");
	}
	
	@Test
	public void test2() 
	{
		driver.findElement(By.id("about-link")).click();;
		String title = driver.getTitle();
		System.out.println(title);
		assertEquals(title,"About Training Support");
	}
	
	@BeforeMethod
	public void beforeMethod() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AbhishekMondal\\Desktop\\IBM_FST\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net");
	}

	@AfterMethod
	public void afterMethod() {
		driver.close();
	}

}
