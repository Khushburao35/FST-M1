package Activity;

import org.testng.annotations.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class Activity09 {

	WebDriver driver;

	@Test
	public void simpleAlertTestCase() {
        Reporter.log("simpleAlertTestCase() started");
        driver.findElement(By.id("simple")).click();
        Alert simpleAlert = driver.switchTo().alert();
        Reporter.log("In Alert");
        String alertText = simpleAlert.getText();
        Reporter.log("Alert text is: " + alertText);
        Assert.assertEquals("This is a JavaScript Alert!", alertText);
        simpleAlert.accept();
        Reporter.log("Alert closed");
        Reporter.log("Test case ended");
    }
 
    @Test
    public void confirmAlertTestCase() {
        Reporter.log("confirmAlertTestCase() started");
        driver.findElement(By.id("confirm")).click();
        Alert confirmAlert = driver.switchTo().alert();
        String alertText = confirmAlert.getText();
        Reporter.log("Alert text is: " + alertText);
        Assert.assertEquals("This is a JavaScript Confirmation!", alertText);
        confirmAlert.accept();
        Reporter.log("Alert closed");
        Reporter.log("Test case ended");
    }
 
    @Test
    public void promptAlertTestCase() {
        Reporter.log("promptAlertTestCase() started");
        driver.findElement(By.id("prompt")).click();
        Reporter.log("Prompt Alert opened");
        Alert promptAlert = driver.switchTo().alert();
        Reporter.log("Switched foucs to alert");
        String alertText = promptAlert.getText();
        Reporter.log("Alert text is: " + alertText + "");
        promptAlert.sendKeys("Awesome!");
        Reporter.log("Text entered in prompt alert");
        Assert.assertEquals("This is a JavaScript Prompt!", alertText);
        promptAlert.accept();
        Reporter.log("Alert closed");
        Reporter.log("Test case ended");
    }
 
	
	
	@BeforeMethod
    public void beforeMethod() {
        Reporter.log("defaultContent");
        driver.switchTo().defaultContent();
    }
	
	
	@BeforeClass
	public void beforeClass() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AbhishekMondal\\Desktop\\IBM_FST\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/javascript-alerts");
		Reporter.log("Page title : " + driver.getTitle());
	}

	@AfterClass
	public void afterMethod() {
		driver.close();
	}

}


