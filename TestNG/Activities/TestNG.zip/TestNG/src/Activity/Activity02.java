package Activity;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;

public class Activity02 {

	WebDriver driver;

	@Test
	public void test1() 
	{
		String title = driver.getTitle();
		System.out.println(title);
		assertEquals(title,"Target Practice");
	}

	@Test
	public void test2() 
	{
		WebElement back_button = driver.findElement(By.xpath(".//button/i[contains(@class,'left arrow icon')]"));
		System.out.println(back_button.getText());
		Assert.assertFalse(back_button.isDisplayed());

	}

	@Test(enabled = false)
	public void test3()
	{
		System.out.println("Test 3");
	}

	@Test
	public void test4() 
	{
		throw new SkipException("Skipping test case");      
	}
	
	@BeforeMethod
	public void beforeMethod() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AbhishekMondal\\Desktop\\IBM_FST\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}

	@AfterMethod
	public void afterMethod() {
		driver.close();
	}

}
