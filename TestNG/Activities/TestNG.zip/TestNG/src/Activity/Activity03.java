package Activity;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class Activity03 {

	WebDriver driver;

	@Test
	public void test2() 
	{
		driver.findElement(By.id("username")).sendKeys("admin");
		driver.findElement(By.id("password")).sendKeys("password");
		driver.findElement(By.xpath(".//button[contains(text(),'Log in')]")).click();
		WebDriverWait wait = new WebDriverWait (driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Welcome Back,')]")));
		String text =driver.findElement(By.xpath("//div[contains(text(),'Welcome Back,')]")).getText();
		Assert.assertEquals(text, "Welcome Back, admin");
		
	}

	@BeforeMethod
	public void beforeMethod() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\AbhishekMondal\\Desktop\\IBM_FST\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/login-form");
	}

	@AfterMethod
	public void afterMethod() {
		driver.close();
	}

}
