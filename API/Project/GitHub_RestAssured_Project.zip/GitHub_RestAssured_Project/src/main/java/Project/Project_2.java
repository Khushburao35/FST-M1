package Project;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Project_2 {

	RequestSpecification requestSpec;
	ResponseSpecification responseSpec;
	String SSH_key = "";
	int SSH_key_ID ;


	@BeforeClass
	public void setUp() {
		// Create request specification
		requestSpec = new RequestSpecBuilder()
				.setContentType(ContentType.JSON)
				.setBaseUri("https://api.github.com")
				.addHeader("Authorization", "Bearer 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" )
				.build();
	}


	@Test(priority=1)

	public void post() {
		System.out.println("POST");

		String reqBody = "{\"title\":\"FST\",\"key\":\"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC6c5hAbhq6ZeM8uilBUUeIfU1oPeW/jTc1CPv/RySpr5DBFeOZ1m8gGpTKzcbFoWB4lw8HgF8MFckGDAJByXmEF4B8TB6UbbCGVy6NVGFvwqOmGG24vczkspiMvP1gmhOI+7yqE7cDvzhVvN4HqLEl39qxyYGcP9FT9oH1NluRPsbhWpcaCNSDa4qQ4Xn8Yg5+feEj3NKeUq46oePiqt5r6RSOe/yACzCLvJjj9H5snmV1XKbuVL2OlG7Y4Nh9BdBNzaldrSVa1RizGRUFkHxD+okBH8mLYJ1W1moaTz24e0xCpkAjRAT0iKoBvLYZDdpbyacRE3bl3GAhYBcmBfwhyAheYMCY7v1qAZ8ia/fWaUT3CPeQCIKkAUWJuIPHHPzaSnExsIyVlPZOotTvrBtakQ2hXt/NFrGvxnu1cxIeBMWIO/kpe6oB4dbex1/ge1/kbmrgPE1oumlMGsuN5J465hbcEVNULa00THZu/zUpXjkQw+UMd/UHXOJ9lhO8gkM=\",\"read_only\" : true}";
		Response response = given().spec(requestSpec) // Use requestSpec
				.body(reqBody) // Send request body
				.when().post("/user/keys"); // Send POST request

		SSH_key_ID = response.path("id");
		System.out.println("POST Request -->\n" + reqBody);
		System.out.println("POST Resposne -->\n" + SSH_key_ID + "\n" + response.getBody().asPrettyString());
		//Reporter.log("POST Resposne -->\n" + response.getBody().asPrettyString());

	} 

	@Test(priority=2)

	public void get() {
		System.out.println("GET");

		Response response = given().spec(requestSpec) // Use requestSpec
				.when().get("/user/emails"); // Send POST request

		System.out.println("GET Resposne -->\n" + response.getBody().asPrettyString());
		//Reporter.log("POST Resposne -->\n" + response.getBody().asPrettyString());

	} 
	
	@Test(priority=3)

	public void delete() {
		System.out.println("DELETE");

		Response response = given().spec(requestSpec) // Use requestSpec
				.pathParam("keyId", SSH_key_ID)
				.when().delete("/user/keys/{keyId}"); // Send POST request

		System.out.println("DELETE Status code--> " + response.getStatusCode());
		//Reporter.log("POST Resposne -->\n" + response.getBody().asPrettyString());
		
		//Assertion
		response.then().statusCode(204);

	}

}